"""Transport exercise of the independent ROS witness. Only synthetic observations on isolated DDS."""
import json
from pathlib import Path
import sys
import time

import rclpy
from geometry_msgs.msg import TwistStamped
from nav_msgs.msg import Odometry
from rclpy.executors import SingleThreadedExecutor
from rclpy.qos import qos_profile_sensor_data
sys.path.insert(0,"/opt/edge/agent")
from rover_maneuver_ros import Witness

rclpy.init()
source=rclpy.create_node("fixture_measurements")
scope={"ros_domain_id":source.context.get_domain_id(),"site_digest":"offline","approval_digest":None}
topics={"odom":"/fixture/odom","report":"/fixture/report","witness":"/fixture/mocap","witness_frame":"mocap",
        "stop_witness":"/fixture/independent_speed","stop_frame":"axle","submit":"/fixture/submit",
        "query":"/fixture/query","cancel":"/fixture/cancel","odom_frame":"odom","base_frame":"base_link"}
watch=Witness({"limits":{"ros":topics},"pin":{"sensor":scope}},"/tmp/no-controller")
pose=source.create_publisher(Odometry,topics["witness"],qos_profile_sensor_data)
brake=source.create_publisher(TwistStamped,topics["stop_witness"],qos_profile_sensor_data)
loop=SingleThreadedExecutor()
loop.add_node(watch)
loop.add_node(source)
last=0
out=[]
try:
    for scenario,speed,frame in (("stationary",0.,"axle"),("moving-brakes",.2,"axle"),("wrong-brake-frame",0.,"other")):
        watch.history.clear()
        watch.braking.clear()
        deadline=time.monotonic()+1.5
        while time.monotonic()<deadline:
            stamp=source.get_clock().now().to_msg()
            odom=Odometry()
            odom.header.stamp=stamp
            odom.header.frame_id="mocap"
            odom.pose.pose.orientation.w=1.
            pose.publish(odom)
            speed_msg=TwistStamped()
            speed_msg.header.stamp=stamp
            speed_msg.header.frame_id=frame
            speed_msg.twist.linear.x=speed
            brake.publish(speed_msg)
            for i in range(5):
                loop.spin_once(timeout_sec=.005)
            time.sleep(.018)
        assert watch.history,scenario
        result=watch.quiet(watch.history[0].stamp,watch.history[-1].stamp)
        assert bool(result)==(scenario=="stationary"),scenario
        out.append({"fixture":scenario,"independent_stop_verified":bool(result),"pose_samples":len(watch.history),
                    "brake_samples":len(watch.braking),"evidence":result})
    print(json.dumps({"environment":"docker --network none, isolated local ROS messages","inputs":out},indent=2))
finally:
    loop.shutdown()
    watch.destroy_node()
    source.destroy_node()
    rclpy.shutdown()
